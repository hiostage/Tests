from fastapi import HTTPException, Response, Request
from sqlalchemy.ext.asyncio import AsyncSession

from sqlalchemy import select, delete, asc, desc

from app.models.Users import User

from passlib.hash import bcrypt

from app.services.session_manager import create_session, get_user_id_from_session


class UserLogic():
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_users(self):
        result = await self.db.execute(select(User).order_by(User.id.asc()))
        obj = result.scalars().all()

        return obj
    
    async def put_user(self, user_data, event_id):
        stmt = select(User).filter(User.id == event_id)
        result = await self.db.execute(stmt)
        obj = result.scalars().first()

        if not obj:
            raise HTTPException(status_code=404, detail="User not found")
        
        data = user_data.model_dump(exclude_unset=True)
        for key, value in data.items():
            setattr(obj, key, value)

        await self.db.commit()
        await self.db.refresh(obj)

        return obj
    
    async def delete_all_users(self):
        await self.db.execute(delete(User))
        await self.db.commit()
        return {"status": "ok"}

    async def delete_user(self, event_id):
        stmt = select(User).filter(User.id == self.event_id)
        result = await self.db.execute(stmt)
        obj = result.scalars().first()

        if not obj:
            raise HTTPException(status_code=404, detail="User not found")

        await self.db.delete(obj)
        await self.db.commit()

        return {"status": f"{obj.id} deleted."}
    
    async def login_user(self, user_data, response: Response):
        stmt = select(User).filter(User.name == user_data.name)
        result = await self.db.execute(stmt)
        user = result.scalars().first()

        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        if not bcrypt.verify(user_data.password, user.password):
            raise HTTPException(status_code=401, detail="Invalid password")
        
        create_session(response, user.id)
        
        return {"message":"Login success", "user_data": {"id":user.id, "name":user.name}}
    

    async def get_correct_user(self, request: Request) -> User:
        user_id = get_user_id_from_session(request)
        if not user_id:
            raise HTTPException(status_code=401, detail="Not authenticated")
        
        stmt = select(User).filter(User.id == user_id)
        result = await self.db.execute(stmt)
        user = result.scalars().first()

        if not user:
            HTTPException(status_code = 404, datails = "User not found")

        return user
        
