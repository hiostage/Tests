from fastapi import APIRouter

subscriptions_router = APIRouter(tags=["subscriptions"])
