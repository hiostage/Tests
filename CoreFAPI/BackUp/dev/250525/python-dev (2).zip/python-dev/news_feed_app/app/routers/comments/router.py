from fastapi import APIRouter

comments_router = APIRouter(tags=["comments"])
