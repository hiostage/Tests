from fastapi import APIRouter

media_router = APIRouter(tags=["media"])
