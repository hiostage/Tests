from typing import TYPE_CHECKING

import pytest
from database.models import Posts, Subscriptions
from dependencies.user import get_user
from tests.utils.fake_depends import fake_depends_async, override_dependency
from tests.utils.fake_users import fake_news_maker_user, fake_news_maker_user_2

if TYPE_CHECKING:
    from core.classes.app import CustomFastApi
    from httpx import AsyncClient
    from sqlalchemy.ext.asyncio import AsyncSession


@pytest.mark.subscriptions_router
@pytest.mark.asyncio
async def test_create_subscription_repeat_subscription(
    client: "AsyncClient", session: "AsyncSession", app: "CustomFastApi"
) -> None:
    """
    Тестирует попытку повторного создания подписки на одного и того же автора (ожидается ошибка 400).

    Шаги:
    1. Создаёт пост автора в базе данных.
    2. Создаёт подписку пользователя на автора и сохраняет в базе.
    3. Пытается подписаться на того же автора повторно через API.
    4. Проверяет, что сервер возвращает статус 400 (Bad Request).

    :param client: Асинхронный HTTP клиент для выполнения запросов.
    :param session: Асинхронная сессия базы данных.
    :param app: Экземпляр FastAPI приложения с переопределёнными зависимостями.
    """
    author = fake_news_maker_user
    user = fake_news_maker_user_2

    # Создадим пост в БД.
    post = Posts(user_id=author.id, title="title", content="content")
    session.add(post)

    # Создадим подписку
    subscription = Subscriptions(user_id=user.id, author_id=author.id)
    session.add(subscription)
    await session.commit()
    assert subscription.created_at
    assert post.id

    # Подпишемся на автора повторно. Ожидаем 400.
    fake_depends_list = [(get_user, fake_depends_async(user))]
    async with override_dependency(app, fake_depends_list):
        response = await client.post(
            "/api/news/subscription", params={"author_id": str(author.id)}
        )
        assert response.status_code == 400
