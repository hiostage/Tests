from fastapi import APIRouter

posts_router = APIRouter(tags=["posts"])
