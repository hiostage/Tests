from fastapi import APIRouter

likes_router = APIRouter(tags=["likes"])
