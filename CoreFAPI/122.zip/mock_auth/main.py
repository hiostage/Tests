from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse
import uvicorn

app = FastAPI()

MOCK_USERS = {
    "test_session": {  # Используем тот же ключ, что и в рабочей версии
        "user_id": 1,
        "username": "test_user",
        "permissions": ["groups.read", "groups.write"],
        "is_active": True
    },
    "another_session": {
        "user_id": 2,
        "username": "another_user",
        "permissions": ["groups.read"],
        "is_active": True
    },
}

@app.get("/check_session")
async def check_session(request: Request):
    session_id = request.cookies.get("session_id")
    if not session_id:
        raise HTTPException(
            status_code=401,
            detail="Session cookie not found",
            headers={"WWW-Authenticate": "Cookie"}
        )
    if session_id not in MOCK_USERS:
        raise HTTPException(
            status_code=401,
            detail="Invalid session ID",
            headers={"WWW-Authenticate": "Cookie"}
        )
    return MOCK_USERS[session_id]

@app.get("/health")
async def health_check():
    return {"status": "ok", "service": "mock_auth"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8080)